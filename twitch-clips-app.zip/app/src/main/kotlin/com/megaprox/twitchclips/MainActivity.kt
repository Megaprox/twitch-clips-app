package com.megaprox.twitchclips

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject
import org.json.JSONArray

data class Clip(val id: String, val url: String, val title: String, val creator: String, val created: String)

class TwitchApi(private val clientId: String, private val token: String) {
    private val client = OkHttpClient()
    private fun req(path: String, method: String = "GET", body: RequestBody? = null): JSONObject {
        val b = Request.Builder()
            .url("https://api.twitch.tv/helix/$path")
            .addHeader("Client-ID", clientId)
            .addHeader("Authorization", "Bearer $token")
        if (method != "GET") b.method(method, body ?: "".toRequestBody())
        client.newCall(b.build()).execute().use { r ->
            val txt = r.body?.string() ?: ""
            if (!r.isSuccessful) throw Exception("Twitch ${r.code}: $txt")
            return JSONObject(txt)
        }
    }
    fun user(login: String): JSONObject {
        val d=req("users?login=$login").getJSONArray("data")
        if (d.length()==0) throw Exception("Canal no encontrado")
        return d.getJSONObject(0)
    }
    fun createClip(broadcasterId: String): String {
        val o=req("clips?broadcaster_id=$broadcasterId","POST")
        return o.getJSONArray("data").getJSONObject(0).getString("id")
    }
    fun clips(broadcasterId: String): List<Clip> {
        val d=req("clips?broadcaster_id=$broadcasterId&first=20").getJSONArray("data")
        return (0 until d.length()).map {
            val x=d.getJSONObject(it)
            Clip(x.optString("id"),x.optString("url"),x.optString("title"),
                 x.optString("creator_name"),x.optString("created_at"))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TwitchClipsScreen() }
    }
}

@Composable
fun TwitchClipsScreen() {
    var clientId by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var channel by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Introduce tus datos de Twitch") }
    var broadcasterId by remember { mutableStateOf("") }
    var clips by remember { mutableStateOf<List<Clip>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val scope=rememberCoroutineScope()

    fun api()=TwitchApi(clientId.trim(),token.trim())

    MaterialTheme {
        Scaffold(topBar={TopAppBar(title={Text("🎬 Twitch Clips")})}) { pad ->
            LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                item {
                    Text("Crear clips desde tu Android", style=MaterialTheme.typography.headlineSmall)
                    Text("Necesitas un Client ID y un OAuth Access Token de Twitch con permisos para crear clips.")
                }
                item { OutlinedTextField(clientId,{clientId=it},label={Text("Client ID de Twitch")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
                item { OutlinedTextField(token,{token=it},label={Text("OAuth Access Token")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
                item { OutlinedTextField(channel,{channel=it},label={Text("Nombre de tu canal")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Button(enabled=!loading,onClick={
                            loading=true; status="Conectando..."
                            scope.launch(Dispatchers.IO) {
                                try {
                                    val u=api().user(channel)
                                    broadcasterId=u.getString("id")
                                    val name=u.getString("display_name")
                                    val list=api().clips(broadcasterId)
                                    clips=list
                                    status="Conectado como $name"
                                } catch(e:Exception) { status=e.message ?: "Error" }
                                loading=false
                            }
                        }) { Text("Conectar") }
                        Button(enabled=!loading && broadcasterId.isNotEmpty(),onClick={
                            loading=true; status="Creando clip..."
                            scope.launch(Dispatchers.IO) {
                                try {
                                    val id=api().createClip(broadcasterId)
                                    status="¡Clip creado! ID: $id"
                                    clips=api().clips(broadcasterId)
                                } catch(e:Exception) { status=e.message ?: "Error" }
                                loading=false
                            }
                        }) { Text("CREAR CLIP") }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) { Text(status,Modifier.padding(14.dp)) }
                }
                item { Text("Últimos clips",style=MaterialTheme.typography.titleLarge) }
                items(clips) { c ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(c.title.ifBlank{"Clip de Twitch"},style=MaterialTheme.typography.titleMedium)
                            Text("Por ${c.creator} · ${c.created}")
                            Text(c.url)
                        }
                    }
                }
            }
        }
    }
}
