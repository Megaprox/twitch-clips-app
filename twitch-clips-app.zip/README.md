# Twitch Clips App

Aplicación Android para conectar con Twitch, consultar tu canal, crear clips y listar los últimos clips.

## Construcción
El proyecto usa Android Gradle Plugin y Kotlin/Jetpack Compose.

## Twitch
Necesitas crear una aplicación en el portal de desarrolladores de Twitch y obtener Client ID y un OAuth Access Token con permisos adecuados para clips.

## Importante
No compartas públicamente tu OAuth token. La versión 1 guarda los datos solo en memoria mientras está abierta.
